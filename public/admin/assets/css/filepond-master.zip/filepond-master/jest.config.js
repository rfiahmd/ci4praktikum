module.exports = {
    bail: true,
    verbose: true,
    setupFiles: ['<rootDir>/jest.stubs.js'],
    roots: ['<rootDir>/src/js']
};