export const composeObject = (...objects) => {
    return Object.assign({}, ...objects);
};
